"""Fixed windows versus paragraph/sentence-aware chunks, always within one page."""
import hashlib
import re
from .models import Chunk, DocumentPage


def _chunk(page: DocumentPage, start: int, end: int) -> Chunk:
    text = page.text[start:end]
    identity = f'{page.document_id}:{page.page}:{start}:{end}:{text}'
    chunk_id = hashlib.sha256(identity.encode()).hexdigest()[:24]
    return Chunk(chunk_id, page.document_id, page.source, page.page, text,
                 dict(page.metadata, document_id=page.document_id, source=page.source,
                      page=page.page, start_char=start, end_char=end))


def fixed_size(page: DocumentPage, size: int, overlap: int) -> list[Chunk]:
    if size < 1 or overlap < 0 or overlap >= size:
        raise ValueError('Require size > overlap >= 0.')
    chunks = []
    for start in range(0, len(page.text), size - overlap):
        end = min(start + size, len(page.text))
        if page.text[start:end].strip():
            chunks.append(_chunk(page, start, end))
        if end == len(page.text):
            break
    return chunks


def by_paragraph(page: DocumentPage, max_size: int) -> list[Chunk]:
    if max_size < 1:
        raise ValueError('max_size must be positive.')
    chunks = []
    start = 0
    while start < len(page.text):
        while start < len(page.text) and page.text[start].isspace():
            start += 1
        if start == len(page.text):
            break
        limit = min(start + max_size, len(page.text))
        end = limit
        if limit < len(page.text) and not (
            page.text[limit - 1] in '.!?' and page.text[limit].isspace()
        ):
            window = page.text[start:limit]
            paragraphs = [m.start() for m in re.finditer(r'\n\n', window) if m.start() > 0]
            sentences = [m.start() for m in re.finditer(r'(?<=[.!?])\s+', window) if m.start() > 0]
            words = [m.start() for m in re.finditer(r'\s+', window) if m.start() > 0]
            boundaries = paragraphs or sentences or words
            if boundaries:
                end = start + boundaries[-1]
        while end > start and page.text[end - 1].isspace():
            end -= 1
        if end == start:
            end = limit
        chunks.append(_chunk(page, start, end))
        start = end
    return chunks
